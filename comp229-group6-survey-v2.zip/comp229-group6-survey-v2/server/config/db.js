module.exports = 
{
    "URI": "mongodb+srv://easySurvey:x49OUKLAehRO22az@cluster0.0bfccxu.mongodb.net/survey_list?retryWrites=true&w=majority"
}